#include "lite_vector.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>


/**
 * Create a new lite_vector.
 *
 * @param type_size The number of bytes for a single element of the type
 *                  to be stored in the vector.
 * @return The vector, or NULL if the operation fails.
 */
lite_vector* lv_new_vec(size_t type_size){
    //allocates memory to store the vector
    lite_vector * vec = (lite_vector*)malloc(sizeof(lite_vector));
    if (!vec){ //if memory allocation fails, it should return null
        printf("Memory allocation failed.");
        return NULL;
    }
    //Initializes length to zero, as there is nothing contained
    //in the vector upon initialization
    
    vec->length = 0;
    vec->max_capacity = 0;

    //sets the size of the data types we want to store
    vec->type_size = type_size;

    //Allocates enough memory for the data arrayw
    printf("Initialized lv\n");
    vec->data = (void**)malloc(sizeof(void*));
    if(!vec->data){
        printf("Memory allocation failed.");
        free(vec); //clean up the data if allocation fails
        return NULL;
    }
    return vec;

}

/**
 * Free all memory used by the vector.  Should be called
 * whenever the vector is no longer needed.
 *
 * @param vec The address of the vector we are finished using.
 */
void lv_cleanup(lite_vector* vec){
    //only tries to free memory if there is actually memory allocated
    if (vec){
        if (vec->data){
            //frees the data first before we lose the pointer
            free(vec->data);
        }
        //frees the rest of the structure, including the pointer to data
        free(vec);
    }
}

/**
 * Get the current number of elements stored in the vector.
 *
 * @param vec The address of the vector we want to know the length of.
 * @return The vector length, or 0 if the operation fails.
 */
size_t lv_get_length(lite_vector* vec){
    //if there is memory allocated for the vector, return the value stored in vec->length
    if (vec){

        return vec->length;
    }
    return 0;
}


/**
 * Clear the contents of the vector and reset it to a default state.
 *
 * @param vec The address of the vector we wish to clear.
 * @retun Sends true on success, or false otherwise.
 */
bool lv_clear(lite_vector* vec){
    //if there is memory allocated for the vector:
    //check that there is memory allocated for the data array
    if (vec){
        if(vec->data){
            //for every element in the array, free that element
            for(size_t i = 0; i < vec->length; ++i){

                free(vec->data[i]);//frees each element individually
            }
            vec->length = 0; //resets size to zero
            printf("returns true\n");
            return true;
        }
    }
    return false;
}

/**
 * Get an element from an index from a vector.
 *
 * @param vec The address of the vector we wish to retrieve from.
 * @param index The index we wish to retrieve from.
 * @return An element from the vector.  NULL if doesn't exist or
 *	   the function cannot complete.
 */
void* lv_get(lite_vector* vec, size_t index){
    if(index < vec->length){
        return vec->data[index];
    }
    return NULL;
}

/**
 * lv_resize is essentially private since we marked it static.
 * The job of this function is to attempt to resize the vector.
 * There may be functions you can call to do this for you, or
 * you may write it yourself.  Either way it isn't too hard.
 * With everything though, check to make sure the code worked
 * and return appropriately.  Do NOT destroy the data if the code
 * fails.  If the resize cannot complete, the original vector
 * must remain unaffected.
 */
static bool lv_resize(lite_vector* vec){
    //how can we resize if we do not have a parameter telling us what
    //to change the size to?
    //resize it to be able to fit one additional element, and then call
    //this function every time you add a new element
    void ** newdata = (void**)malloc(sizeof(void*) * (vec->max_capacity + 1));
    vec->data = newdata;
    
    vec->max_capacity = (size_t) (vec->max_capacity + 1);
    return vec;
}
/**
 * Add an element to the vector, and extend the vector if needed.
 *
 * @param vec The address of the vector we wish to add to.
 * @param element The element we wish to add.
 * @return Will return true if successful, false otherwise.
 */
bool lv_append(lite_vector* vec, void* element){
    //check if resizing is needed:
    if(vec->length >= vec->max_capacity){
        //printf("resizing\n");
        lv_resize(vec);
    }
    /*
    printf("succesfully resized\n");
    printf("\nfinal size of array %zu\n", (vec->length ));
    printf("\nsize of array %lu\n", vec->length / vec->type_size);
    printf("element address %p\n", element);
    */
    vec->data[vec->length] = element;
    //printf("data[0] address %p\n", vec->data[0]);
    vec->length++;
    
    
    
    
    return true;

}

